import {createOfficeNavigation} from './office-navigation.js';
import {createViewer} from '@playcanvas/supersplat-viewer/viewer';
import '@playcanvas/supersplat-viewer/viewer.css';
import bada from './scene.json';
import luzhai from './luzhai.json';
import pond from './bada-pond.json';
import miaoji from './miaoji.json';
const officeBase={destination:'office',label:'我的公司 · 实拍探索',source:'/office-source.html',credit:'用户自行拍摄',scope:'由视频前约 71 秒的 212 帧重建，院子、大厅、楼梯和二楼在同一个三维模型中，可连续步行。选择起点可快速到达对应位置。单目重建与楼梯碰撞有估计误差；720p 原片未拍清或未覆盖的方向仍可能模糊。'};
const scenes={
 office:{...officeBase,title:'走进熟悉的院子。',area:'院子',waypoint:'yard'},
 'office-entrance':{...officeBase,title:'从门口，走进大厅。',area:'楼前入口',waypoint:'entrance'},
 'office-lobby':{...officeBase,title:'走进一楼大厅。',area:'一楼大厅',waypoint:'lobby'},
 'office-stairs':{...officeBase,title:'沿着楼梯，继续走。',area:'楼梯起点',waypoint:'stairs'},
 'office-upstairs':{...officeBase,title:'到二楼，看看。',area:'二楼走廊',waypoint:'upstairs'},
 bada:{data:bada,destination:'bada',title:'在庭院里，慢慢走。',area:'纪念馆庭院',label:'南昌 · 八大山人纪念馆',id:'ef4004b8',credit:'luckysplat · CC BY 4.0',scope:'当前开放庭院与池塘两处独立实景，可切换区域继续探索。'},
 'bada-pond':{data:pond,destination:'bada',title:'沿着池塘，走一走。',area:'青云谱池塘',label:'南昌 · 八大山人纪念馆',id:'2761f458',credit:'luckysplat · CC BY 4.0',scope:'这是纪念馆内的池塘扫描片段，与庭院分开加载，暂未无缝连接。'},
 luzhai:{data:luzhai,destination:'luzhai',title:'走进卢宅的古巷。',area:'牌坊与古巷',label:'浙江 · 东阳卢宅',id:'ab68fa37',credit:'SHARE / SuperSplat',scope:'当前开放牌坊与相邻古巷。街道远端扫描细节不足，清晰模式无法补出未采集的内容。'},
 miaoji:{data:miaoji,destination:'miaoji',title:'到古桥边，听听风。',area:'古桥与古樟',label:'南昌 · 梅岭妙济桥',id:'2b617c36',credit:'luckysplat / SuperSplat',scope:'当前开放妙济桥与周边古樟的扫描片段，不代表整个梅岭景区。'}
};
const requested=new URLSearchParams(location.search).get('scene');
const key=Object.hasOwn(scenes,requested)?requested:(/^\/luzhai(?:\.html)?\/?$/.test(location.pathname)?'luzhai':'bada');
const current=scenes[key];let scene=current.data;
const $=id=>document.getElementById(id);
const sceneUrl=id=>{
 const url=new URL(location.href);
 url.pathname='/';
 url.searchParams.set('scene',id);
 return url.pathname+url.search+url.hash;
};
// Make default and legacy entrances shareable with the resolved scene too.
history.replaceState(history.state,'',sceneUrl(key));
$('destination').value=current.destination;
document.title='行前漫游 · '+current.label;
document.querySelector('.place h1').textContent=current.title;
$('world').setAttribute('aria-label',current.label+' · '+current.area+'，可自由步行的实景');
document.querySelector('#loading h2').textContent='正在走进'+current.area;
$('credit').textContent='实景：'+current.credit;
$('source').href=current.source??('https://superspl.at/scene/'+current.id);
$('scene-scope').textContent=current.scope;
$('attribution').textContent='素材作者：'+current.credit+'。本站修改交互界面、初始视角和渲染配置，使用原作者公开发布的流式场景与碰撞数据。未注明开放许可的素材，其权利仍归原作者。渲染器：SuperSplat Viewer / PlayCanvas（MIT）。';
if(current.destination==='office')$('attribution').textContent='用户自行拍摄并授权本次公开展示。本站从视频选取 212 帧，以统一相机标定和全局 SfM 连通院子、大厅与楼梯，再训练 Gaussian Splatting。行走地面和楼梯坡面为估计值，未做实地测量。';
$('about-source').href=$('source').href;
const area=$('area');
for(const [id,item] of Object.entries(scenes)){if(item.destination===current.destination){const option=new Option(item.area,id);area.add(option);}}
area.value=key;
area.onchange=()=>{location.href=sceneUrl(area.value);};
$('area-picker').hidden=area.options.length<2;
$('coverage').textContent=current.destination==='bada'?'已开放 2 个实景区域 · 可切换探索':'已开放局部实景 · 扫描边缘可能模糊';
if(current.destination==='office')$('coverage').textContent='院子 → 大厅 → 楼梯 → 二楼 · 连续步行';
if(current.destination==='office'){$('area-help').textContent='公司场景的各起点属于同一个连续三维模型，可以直接步行前往，也可以通过「选择起点」快速到达。楼梯碰撞为近似坡面，未做实地测量。';$('area-label').textContent='选择起点';$('source').textContent='拍摄与重建说明 ↗';}
const status=$('loadingText');let viewer,ready=false,officeNav;
let joyPointer=null;
function stop(){if(officeNav)officeNav.stop();else if(viewer?.state.loaded)viewer.setMoveInput(0,0);joyPointer=null;$('knob').style.transform='translate(-50%,-50%)';}
// Refresh detail sooner during walking and looking around. This does not fill scan gaps.
function tuneWalkingDetail(){
 if(!viewer?.state.loaded)return;
 const gsplat=viewer.app.scene.gsplat,fast=viewer.state.performanceMode;
 gsplat.lodUpdateAngle=fast?45:20;
 gsplat.lodUpdateDistance=fast?0.75:0.35;
 gsplat.lodBehindPenalty=fast?5:2;
 viewer.app.renderNextFrame=true;
}
function setReady(){
 if(!viewer.state.loaded||!viewer.state.walkAllowed)return;
 if(ready)return;
 ready=true;viewer.state.cameraMode='walk';viewer.state.gamingControls=true;viewer.state.inputEnabled=current.destination!=='office';
 if(current.destination==='office')officeNav=createOfficeNavigation(viewer,scene.route,scene.settings.cameras[0].initial,$('world'));

 queueMicrotask(tuneWalkingDetail);
 $('loading').hidden=true;$('pad').disabled=false;$('mode').textContent='步行中';
}
function failed(message){status.textContent=message;$('retry').hidden=false;}
try{
 scene??=await fetch('/office/scene.json?v=11').then(r=>{if(!r.ok)throw new Error('公司场景暂不可用');return r.json();});
 if(current.destination==='office')scene.route=await fetch('/office/route.json?v=11').then(r=>{if(!r.ok)throw new Error('行走路线暂不可用');return r.json();});
 if(current.waypoint&&scene.waypoints?.[current.waypoint])scene.settings.cameras[0].initial=scene.waypoints[current.waypoint];
 scene.settings.animTracks=[];scene.settings.startMode='default';
 viewer=await createViewer({container:$('world'),...scene,ui:false,lang:'zh-CN',renderer:'webgl',noanim:true});
 viewer.state.inputEnabled=false;viewer.state.performanceMode=false;
 viewer.events.on('progress:changed',p=>{status.textContent=`正在加载实景 ${Math.round(p)}%`;});
 viewer.events.on('loaded:changed',()=>{status.textContent='正在准备可行走地面…';setReady();});
 viewer.events.on('walkAllowed:changed',setReady);
 viewer.events.on('performanceMode:changed',()=>queueMicrotask(tuneWalkingDetail));
 viewer.events.on('cameraMode:changed',mode=>{if(ready&&mode!=='walk')viewer.state.cameraMode='walk';});
 setReady();
 setTimeout(()=>{if(!ready)failed('加载较慢，请稍候，或点击重试。');},45000);
}catch(e){console.error(e);failed('实景加载失败，请检查网络后重试。');}
$('retry').onclick=()=>location.reload();
const pad=$('pad');
function move(e){
 const r=pad.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2;
 const radius=r.width*.32,dist=Math.hypot(dx,dy),scale=Math.min(1,radius/(dist||1));
 const x=dx*scale,y=dy*scale;
 $('knob').style.transform=`translate(calc(-50% + ${x}px),calc(-50% + ${y}px))`;
 (officeNav??viewer).setMoveInput(x/radius,-y/radius);
}
pad.addEventListener('pointerdown',e=>{if(!ready)return;e.preventDefault();joyPointer=e.pointerId;pad.setPointerCapture(joyPointer);move(e);});
pad.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)move(e);});
for(const ev of ['pointerup','pointercancel','lostpointercapture'])pad.addEventListener(ev,e=>{if(e.pointerId===joyPointer)stop();});
window.addEventListener('blur',stop);document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
// Keep movement keys from changing the scene into an orbit or fly viewer.
window.addEventListener('keydown',e=>{if(e.code==='Space'&&e.target===document.body)e.preventDefault();if(['1','2','3','f','F'].includes(e.key)&&e.target===document.body){e.preventDefault();e.stopImmediatePropagation();}},true);
$('reset').onclick=()=>{if(ready){stop();if(officeNav)officeNav.reset();else viewer.resetCamera();}};
$('quality').onclick=()=>{if(viewer){viewer.state.performanceMode=!viewer.state.performanceMode;$('quality').textContent=viewer.state.performanceMode?'画质：流畅':'画质：清晰';}};
const about=$('about');
$('help').onclick=()=>{stop();if(document.pointerLockElement)document.exitPointerLock();if(viewer)viewer.state.inputEnabled=false;officeNav?.setEnabled(false);about.showModal();};
$('close-about').onclick=()=>about.close();about.addEventListener('close',()=>{if(ready){if(officeNav)officeNav.setEnabled(true);else viewer.state.inputEnabled=true;}});
$('destination').onchange=e=>{location.href=sceneUrl(e.target.value);};
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else {document.body.classList.toggle('immersive');$('fullscreen').textContent=document.body.classList.contains('immersive')?'退出全屏':'全屏';}}catch{document.body.classList.toggle('immersive');$('fullscreen').textContent=document.body.classList.contains('immersive')?'退出全屏':'全屏';}};
// Readable runtime status supports checking actual camera movement, not merely an active button.
setInterval(()=>{if(!ready)return;const camera=viewer.app.root.findComponents('camera')[0];if(camera){const p=camera.entity.getPosition();$('mode').title=`步行位置 ${p.x.toFixed(2)}, ${p.y.toFixed(2)}, ${p.z.toFixed(2)}`;$('world').dataset.position=[p.x,p.y,p.z].map(v=>v.toFixed(3)).join(',');const angles=camera.entity.getEulerAngles();$('world').dataset.angles=[angles.x,angles.y,angles.z].map(v=>v.toFixed(1)).join(',');if(current.destination==='office'&&p.y< -5)officeNav?.reset();}},500);
