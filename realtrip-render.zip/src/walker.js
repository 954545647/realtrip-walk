import {createViewer} from '@playcanvas/supersplat-viewer/viewer';
import '@playcanvas/supersplat-viewer/viewer.css';
import bada from './scene.json';
import luzhai from './luzhai.json';
const isLuzhai=/^\/luzhai(?:\.html)?\/?$/.test(location.pathname);
const scene=isLuzhai?luzhai:bada;
const $=id=>document.getElementById(id);
$('destination').value=isLuzhai?'luzhai':'bada';
const status=$('loadingText');let viewer,ready=false;
let joyPointer=null;
function stop(){if(viewer?.state.loaded)viewer.setMoveInput(0,0);joyPointer=null;$('knob').style.transform='translate(-50%,-50%)';}
function setReady(){
 if(!viewer.state.loaded||!viewer.state.walkAllowed)return;
 if(ready)return;
 ready=true;viewer.state.cameraMode='walk';viewer.state.gamingControls=true;viewer.state.inputEnabled=true;
 $('loading').hidden=true;$('pad').disabled=false;$('mode').textContent='步行中';
}
function failed(message){status.textContent=message;$('retry').hidden=false;}
try{
 scene.settings.animTracks=[];scene.settings.startMode='default';
 viewer=await createViewer({container:$('world'),...scene,ui:false,lang:'zh-CN',budget:1,renderer:'webgl',noanim:true});
 viewer.state.inputEnabled=false;viewer.state.performanceMode=false;
 viewer.events.on('progress:changed',p=>{status.textContent=`正在加载实景 ${Math.round(p)}%`;});
 viewer.events.on('loaded:changed',()=>{status.textContent='正在准备可行走地面…';setReady();});
 viewer.events.on('walkAllowed:changed',setReady);
 viewer.events.on('cameraMode:changed',mode=>{if(ready&&mode!=='walk')viewer.state.cameraMode='walk';});
 setReady();
 setTimeout(()=>{if(!ready)failed('加载较慢，请稍候，或点击重试。');},45000);
}catch(e){console.error(e);failed('实景加载失败，请检查网络后重试。');}
$('retry').onclick=()=>location.reload();
const pad=$('pad');
function move(e){
 const r=pad.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2;
 const radius=r.width*.32,dist=Math.hypot(dx,dy),scale=Math.min(1,radius/(dist||1));
 const x=dx*scale,y=dy*scale;
 $('knob').style.transform=`translate(calc(-50% + ${x}px),calc(-50% + ${y}px))`;
 viewer.setMoveInput(x/radius,-y/radius);
}
pad.addEventListener('pointerdown',e=>{if(!ready)return;e.preventDefault();joyPointer=e.pointerId;pad.setPointerCapture(joyPointer);move(e);});
pad.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)move(e);});
for(const ev of ['pointerup','pointercancel','lostpointercapture'])pad.addEventListener(ev,e=>{if(e.pointerId===joyPointer)stop();});
window.addEventListener('blur',stop);document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
// Keep movement keys from changing the scene into an orbit or fly viewer.
window.addEventListener('keydown',e=>{if(e.code==='Space'&&e.target===document.body)e.preventDefault();if(['1','2','3','f','F'].includes(e.key)&&e.target===document.body){e.preventDefault();e.stopImmediatePropagation();}},true);
$('reset').onclick=()=>{if(ready){stop();viewer.resetCamera();}};
$('quality').onclick=()=>{if(viewer){viewer.state.performanceMode=!viewer.state.performanceMode;$('quality').textContent=viewer.state.performanceMode?'画质：流畅':'画质：清晰';}};
const about=$('about');
$('help').onclick=()=>{stop();if(document.pointerLockElement)document.exitPointerLock();if(viewer)viewer.state.inputEnabled=false;about.showModal();};
$('close-about').onclick=()=>about.close();about.addEventListener('close',()=>{if(ready)viewer.state.inputEnabled=true;});
$('destination').onchange=e=>{location.href=e.target.value==='luzhai'?'/luzhai':'/';};
$('fullscreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else {document.body.classList.toggle('immersive');$('fullscreen').textContent=document.body.classList.contains('immersive')?'退出全屏':'全屏';}}catch{document.body.classList.toggle('immersive');$('fullscreen').textContent=document.body.classList.contains('immersive')?'退出全屏':'全屏';}};
// Readable runtime status supports checking actual camera movement, not merely an active button.
setInterval(()=>{if(!ready)return;const camera=viewer.app.root.findComponents('camera')[0];if(camera){const p=camera.entity.getPosition();$('mode').title=`步行位置 ${p.x.toFixed(2)}, ${p.y.toFixed(2)}, ${p.z.toFixed(2)}`;}},500);
