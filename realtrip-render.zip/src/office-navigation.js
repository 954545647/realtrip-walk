// Camera-relative walking inside a measured-from-video capture corridor.
// Progress continuity disambiguates overlapping stair flights; heights are approximate.
export function routeProject(route, x, z, progress = null) {
 const p=route.points,w=route.width;
 let best=null;
 for(let i=0;i<p.length-1;i++){
  if(progress!==null&&Math.abs(i-progress)>7)continue;
  const dx=p[i+1][0]-p[i][0],dz=p[i+1][2]-p[i][2],l2=dx*dx+dz*dz;
  const t=Math.max(0,Math.min(1,((x-p[i][0])*dx+(z-p[i][2])*dz)/(l2||1)));
  const px=p[i][0]+t*dx,pz=p[i][2]+t*dz,d=Math.hypot(x-px,z-pz);
  // At a hairpin, retain the current flight instead of cutting across to a later one.
  const score=d*d+(progress===null?0:Math.pow((i+t)-progress,2)*.0025);
  if(!best||score<best.score)best={i,t,progress:i+t,x:px,z:pz,y:p[i][1]+t*(p[i+1][1]-p[i][1]),distance:d,width:w[i]+t*(w[i+1]-w[i]),score};
 }
 return best;
}
export function createOfficeNavigation(viewer, route, initial, world) {
 const cam=viewer.app.root.findComponents('camera')[0].entity;
 let x,z,y,yaw,pitch=0,progress,jumpY=0,jumpV=0,moveX=0,moveZ=0,enabled=true,look=null;
 const keys=new Set(),canvas=world.querySelector('canvas');
 function reset(){
  [x,y,z]=initial.position;const dx=initial.target[0]-x,dz=initial.target[2]-z;
  yaw=Math.atan2(-dx,-dz)*180/Math.PI;pitch=0;jumpY=jumpV=0;keys.clear();moveX=moveZ=0;
  // Position and height together choose the right flight for quick-start locations.
  let nearest=0,score=Infinity;
  route.points.forEach((p,i)=>{const d=(p[0]-x)**2+(p[2]-z)**2+4*(p[1]+1.5-y)**2;if(d<score){score=d;nearest=i;}});
  const hit=routeProject(route,x,z,nearest);progress=hit.progress;y=hit.y+1.5;render();
 }
 function stop(){keys.clear();moveX=moveZ=0;look=null;}
 function jump(){if(enabled&&jumpY===0)jumpV=3.6;}
 function keydown(e){
  if(!enabled||e.target.closest?.('input,select,textarea,dialog'))return;
  if(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)){
   e.preventDefault();keys.add(e.code);if(e.code==='Space'&&!e.repeat)jump();
  }
 }
 function keyup(e){keys.delete(e.code);}
 function turn(dx,dy){yaw-=dx*.16;pitch=Math.max(-75,Math.min(75,pitch-dy*.16));}
 function pointerdown(e){
  if(!enabled)return;
  if(e.pointerType==='mouse'&&viewer.state.gamingControls&&canvas.requestPointerLock){canvas.requestPointerLock()?.catch?.(()=>{});}
  look={id:e.pointerId,x:e.clientX,y:e.clientY,start:performance.now(),travel:0,touch:e.pointerType!=='mouse'};
  if(e.pointerType!=='mouse')canvas.setPointerCapture(e.pointerId);
 }
 function pointermove(e){
  if(!enabled)return;
  if(document.pointerLockElement===canvas){turn(e.movementX,e.movementY);return;}
  if(look?.id===e.pointerId){const dx=e.clientX-look.x,dy=e.clientY-look.y;turn(dx,dy);look.travel+=Math.hypot(dx,dy);look.x=e.clientX;look.y=e.clientY;}
 }
 function pointerup(e){if(look?.id===e.pointerId){if(look.touch&&look.travel<8&&performance.now()-look.start<320)jump();look=null;}}
 let lastRender=[];
 function render(){const next=[x,y+jumpY,z,pitch,yaw];cam.setPosition(x,y+jumpY,z);cam.setEulerAngles(pitch,yaw,0);cam.camera.nearClip=.03;cam.camera.farClip=250;if(next.some((v,i)=>Math.abs(v-(lastRender[i]??Infinity))>1e-5))viewer.app.renderNextFrame=true;lastRender=next;}
 function update(dt){
  dt=Math.min(dt,.1);
  if(enabled){
   let sx=moveX+(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);
   let sz=moveZ+(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
   const n=Math.max(1,Math.hypot(sx,sz));sx/=n;sz/=n;
   const rad=yaw*Math.PI/180,speed=route.times[Math.min(Math.floor(progress),route.times.length-1)]<29?2.5:1.65;
   const nx=x+(Math.cos(rad)*sx-Math.sin(rad)*sz)*speed*dt;
   const nz=z+(-Math.sin(rad)*sx-Math.cos(rad)*sz)*speed*dt;
   const hit=routeProject(route,nx,nz,progress),radius=Math.max(.18,hit.width-.22);
   if(hit.distance>radius){x=hit.x+(nx-hit.x)*radius/hit.distance;z=hit.z+(nz-hit.z)*radius/hit.distance;}else{x=nx;z=nz;}
   progress=hit.progress;y=hit.y+1.5;
   if(jumpV!==0||jumpY>0){jumpV-=9.8*dt;jumpY+=jumpV*dt;if(jumpY<=0){jumpY=0;jumpV=0;}}
  }
  render();world.dataset.routeProgress=progress.toFixed(2);
 }
 window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('blur',stop);
 const visibility=()=>{if(document.hidden)stop();};document.addEventListener('visibilitychange',visibility);
 canvas.addEventListener('pointerdown',pointerdown);canvas.addEventListener('pointermove',pointermove);canvas.addEventListener('pointerup',pointerup);canvas.addEventListener('pointercancel',pointerup);
 viewer.app.on('update',update);reset();
 return {setMoveInput(a,b){moveX=a;moveZ=b;},reset,stop,jump,setEnabled(v){enabled=v;if(!v)stop();},destroy(){viewer.app.off('update',update);window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('blur',stop);document.removeEventListener('visibilitychange',visibility);canvas.removeEventListener('pointerdown',pointerdown);canvas.removeEventListener('pointermove',pointermove);canvas.removeEventListener('pointerup',pointerup);canvas.removeEventListener('pointercancel',pointerup);}};
}
