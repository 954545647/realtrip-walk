import {strict as assert} from 'node:assert';
import {createOfficeNavigation} from '../src/office-navigation.js';

class Events {
  callbacks=new Map();
  addEventListener(type, fn){if(!this.callbacks.has(type))this.callbacks.set(type,new Set());this.callbacks.get(type).add(fn);}
  removeEventListener(type, fn){this.callbacks.get(type)?.delete(fn);}
  send(type, props={}){for(const fn of this.callbacks.get(type)??[])fn({target:{closest(){return null;}},preventDefault(){},...props});}
}
globalThis.window=new Events();window.matchMedia=()=>({matches:false});
globalThis.document=new Events();
const canvas=new Events();canvas.setPointerCapture=()=>{};
let position, update;
const cam={camera:{},setPosition(...p){position=p;},setEulerAngles(){}};
const app={root:{findComponents(){return [{entity:cam}];}},on(_,fn){update=fn;},off(){}};
const route={points:Array.from({length:60},(_,i)=>[0,i>.1?Math.max(0,i-30)*.05:0,-i*.4]),width:Array(60).fill(.7),speed:Array(60).fill(1.5),eyeHeight:1.6};
const world={querySelector(){return canvas;},dataset:{}};
const nav=createOfficeNavigation({app,state:{}},route,{position:[0,1.6,0],target:[0,1.6,-3]},world);
const tick=(n=60)=>{for(let i=0;i<n;i++)update(1/60);};
assert.equal(position[1],1.6);
window.send('keydown',{code:'KeyW'});tick(120);window.send('keyup',{code:'KeyW'});tick(60);
assert(position[2]<-2.7 && position[2]>-3.3,'W must move about three metres in two seconds');
const floor=position[1];window.send('keydown',{code:'Space',repeat:false});tick(18);
assert(position[1]>floor+.3,'Desktop Space must jump');
window.send('keyup',{code:'Space'});tick(120);assert(Math.abs(position[1]-floor)<.01,'Jump returns to the same floor');
nav.setMoveInput(1,0);tick(180);assert(Math.abs(position[0])<=.481,'Joystick cannot leave capture corridor');
nav.stop();const stopped=[...position];tick();assert(Math.hypot(position[0]-stopped[0],position[2]-stopped[2])<1e-6,'Stop cannot drift');
nav.setEnabled(false);window.send('keydown',{code:'KeyW'});nav.setMoveInput(0,1);tick();assert.equal(position[2],stopped[2],'Help dialog pauses movement');
nav.setEnabled(true);nav.reset();nav.setWalkingMotion(false);nav.setMoveInput(0,1);tick(80);assert.equal(position[1],1.6,'Turning walking motion off removes bobbing');
nav.reset();nav.setMoveInput(0,1);let lastY=position[1];
for(let i=0;i<850;i++){update(1/60);assert(Math.abs(position[1]-lastY)<.02,'Ramp cannot cause abrupt vertical jumps');lastY=position[1];}
assert(position[1]>2.1,'Walking continues up the ramp');
nav.destroy();assert.equal(window.callbacks.get('keydown').size,0);
console.log('Office controller: keyboard/touch movement, Space jump, stop, pause, motion toggle, smooth ramp and cleanup pass.');
