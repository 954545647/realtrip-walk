import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createWalkSurface} from '../src/walk-surface.js';
import {explorerScenes,explorerScenePath} from '../src/explorer-ui.js';
const scene=JSON.parse(readFileSync(new URL('../src/cafeteria.json',import.meta.url)));
const surface=createWalkSurface(scene.navigation);
const assetRoot='../public/cafeteria/';
test('cafeteria preserves the three existing scenes and has a shareable entrance',()=>{
 assert.deepEqual(explorerScenes.map(x=>x[0]),['honor-corridor','building2','terrace','cafeteria','cafeteria-original']);
 assert.equal(explorerScenePath('cafeteria','/walk/'),'/walk/?scene=cafeteria');
 assert.equal(explorerScenePath('cafeteria-original','/walk/'),'/walk/?scene=cafeteria-original');
});
test('the people comparison uses the untouched capture alongside the existing cleaned model',()=>{
 const report=JSON.parse(readFileSync(new URL(assetRoot+'original-provenance.json',import.meta.url)));
 const model=readFileSync(new URL(assetRoot+'original.sog',import.meta.url));
 assert.equal(model.length,15334871);
 assert.equal(createHash('sha256').update(model).digest('hex'),'79930154e6f2306642058935509fbbfd7f59747994eefe80f63faab09afea38f');
 assert.equal(report.modelSHA256,report.sourceSHA256);
 assert.equal(report.hiddenHumanSplats,0);
});
test('cafeteria starts are on the reviewed floor and the cleaned model is intact',()=>{
 for(const s of Object.values(scene.waypoints)){
  assert(surface.contains(s.position[0],s.position[2]),JSON.stringify(s.position));
  assert(Math.abs(s.position[1]-surface.floorY-surface.eyeHeight)<1e-6);
  assert.equal(s.landscapeFov,84);
 }
 const report=JSON.parse(readFileSync(new URL(assetRoot+'provenance.json',import.meta.url)));
 const model=readFileSync(new URL(assetRoot+'scene.sog',import.meta.url));
 assert.equal(model.length,report.modelBytes);
 assert.equal(createHash('sha256').update(model).digest('hex'),report.modelSHA256);
 assert(report.hiddenHumanSplats>0&&report.hiddenHumanSplats<report.gaussians*.1);
});
const route=[[-4.65,.65],[-2.5,.4],[-1.65,-.7],[3.8,-.7],[3.8,-3.2],[.6,-3.2],[-.7,-3.2],[-.7,-5.1],[-1.1,-3],[-1.5,-.7],[-1.72,2.35],[.7,2.35],[3.8,2.4],[4.13,2.35],[4.13,-.7],[3.8,-.7],[-1.65,-.7],[-2.5,.4],[-4.65,.65]];
test('entrance, counter aisle, central aisle and dining edge connect in both directions',()=>{
 for(const points of [route,[...route].reverse()]){
  let [x,z]=points[0];
  for(const [nx,nz] of points.slice(1)){
   const foot=surface.move(x,z,nx,nz);
   assert(Math.hypot(foot.x-nx,foot.z-nz)<1e-6,`blocked ${x},${z} → ${nx},${nz}: ${JSON.stringify(foot)}`);
   assert.equal(foot.y,surface.floorY);({x,z}=foot);
  }
 }
});
test('columns, barriers, counters and scan boundaries block swept movement',()=>{
 for(const [from,to] of [
  [[-1.65,.3],[.5,.3]],[[.7,2.35],[1.8,1.5]],[[3.8,-2.4],[1.9,-2.4]],
  [[-.8,2.35],[-1.1,3.1]],[[3.8,-.7],[8,-.7]],[[-.7,-5.1],[-.7,-8]],
  [[-1.5,-2.5],[-3,-2.5]],[[-4.65,.65],[-4.65,4]]
 ]){
  assert(surface.contains(...from));const hit=surface.move(...from,...to);
  assert(surface.contains(hit.x,hit.z));assert(Math.hypot(hit.x-to[0],hit.z-to[1])>.2);
 }
});
