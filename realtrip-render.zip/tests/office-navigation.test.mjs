import {strict as assert} from 'node:assert';
import {readFileSync} from 'node:fs';
import {routeProject} from '../src/office-navigation.js';
const route=JSON.parse(readFileSync(new URL('../public/office/route.json',import.meta.url)));
let progress=0;
for(let i=1;i<route.points.length;i++){
 const p=route.points[i],hit=routeProject(route,p[0],p[2],progress);
 assert(Math.abs(hit.progress-i)<1.1,`Forward route disconnects at ${i}`);
 assert(Math.abs(hit.y-p[1])<.3,`Wrong floor on forward path at ${i}`);progress=hit.progress;
 if(route.times[i-1]>=51)assert(p[1]>=route.points[i-1][1]-.001,'Ascending stairs must not drop to a lower flight');
}
for(let i=route.points.length-2;i>=0;i--){
 const p=route.points[i],hit=routeProject(route,p[0],p[2],progress);
 assert(Math.abs(hit.progress-i)<1.1,`Reverse route disconnects at ${i}`);
 assert(Math.abs(hit.y-p[1])<.3,`Wrong floor on reverse path at ${i}`);progress=hit.progress;
}
// Identical horizontal positions on two floors must stay on their current flight.
const stacked={points:[],width:[]};
for(let i=0;i<30;i++){stacked.points.push([i%15,i<15?0:3,0]);stacked.width.push(.65);}
assert.equal(routeProject(stacked,5.3,0,5.3).y,0);
assert.equal(routeProject(stacked,5.3,0,20.3).y,3);
console.log(`Office navigation: ${route.points.length} route points pass in both directions; staircase levels stay distinct.`);
