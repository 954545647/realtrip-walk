import {test} from 'node:test';
import assert from 'node:assert/strict';
import {bindInputHints} from '../src/explorer-ui.js';
class Events {
 listeners=new Map();
 addEventListener(type,fn){this.listeners.set(type,fn);}
 removeEventListener(type,fn){if(this.listeners.get(type)===fn)this.listeners.delete(type);}
 emit(type,event={}){this.listeners.get(type)?.(event);}
}
function fixture(touch){
 const media=new Events();media.matches=touch;
 const win=new Events();win.matchMedia=()=>media;
 const doc=new Events(),hint={dataset:{},innerHTML:''};
 const dispose=bindInputHints(hint,{win,doc});
 return {media,win,doc,hint,dispose};
}
test('initial hints follow primary input capability, independent of screen width',()=>{
 const phone=fixture(true);assert.equal(phone.hint.dataset.inputMode,'touch');
 assert.match(phone.hint.innerHTML,/轻点画面跳跃/);assert.doesNotMatch(phone.hint.innerHTML,/<kbd>|空格/);
 const pc=fixture(false);assert.equal(pc.hint.dataset.inputMode,'keyboard');assert.match(pc.hint.innerHTML,/空格/);
});
test('hybrid input switches with touch, external keyboard, pen and mouse',()=>{
 const f=fixture(true);
 f.win.emit('keydown',{code:'Space'});assert.equal(f.hint.dataset.inputMode,'keyboard');
 f.doc.emit('pointerdown',{pointerType:'touch'});assert.equal(f.hint.dataset.inputMode,'touch');
 f.doc.emit('pointerdown',{pointerType:'mouse'});assert.equal(f.hint.dataset.inputMode,'keyboard');
 f.doc.emit('pointerdown',{pointerType:'pen'});assert.equal(f.hint.dataset.inputMode,'touch');
});
test('capability changes update hints and all listeners can be removed',()=>{
 const f=fixture(false);f.media.matches=true;f.media.emit('change');assert.equal(f.hint.dataset.inputMode,'touch');
 f.dispose();assert.equal(f.win.listeners.size+f.doc.listeners.size+f.media.listeners.size,0);
});
