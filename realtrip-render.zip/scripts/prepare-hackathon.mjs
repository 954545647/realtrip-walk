import {readFileSync,copyFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
const model=JSON.parse(readFileSync(new URL('./hackathon-model.json',import.meta.url)));
const source=new URL('../../'+model.name,import.meta.url),data=readFileSync(source);
if(data.length!==model.bytes||createHash('sha256').update(data).digest('hex')!==model.sha256)throw Error('Hackathon model checksum mismatch');
const target=new URL('../public/hackathon/',import.meta.url);mkdirSync(target,{recursive:true});
copyFileSync(source,new URL('scene.sog',target));console.log('Hackathon model prepared',data.length,'bytes');
