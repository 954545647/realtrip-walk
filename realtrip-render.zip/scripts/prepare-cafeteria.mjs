import {readFileSync,copyFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
const source=new URL('../../cafeteria-20261017.sog',import.meta.url);
const target=new URL('../public/cafeteria/scene.sog',import.meta.url);
const data=readFileSync(source);
if(data.length!==15316537||createHash('sha256').update(data).digest('hex')!=='f7a89ab8d11404ebc56bf5e03ac215d97a404e677636c1f2866dc258b6b0c145')throw Error('Cafeteria model checksum mismatch');
mkdirSync(new URL('../public/cafeteria/',import.meta.url),{recursive:true});copyFileSync(source,target);
console.log('Cafeteria model prepared',data.length,'bytes');
