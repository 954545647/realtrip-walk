import {readFileSync,copyFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
const source=new URL('../../workstation-20261016.sog',import.meta.url);
const target=new URL('../public/workstation/scene.sog',import.meta.url);
const expected='0ddcf7dc9078f21d3881e96f8cba1483166424c7cbd688f59bb29d784ca8948e';
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
if(!existsSync(target)||hash(target)!==expected){
 if(hash(source)!==expected)throw Error('Workstation model checksum mismatch');
 copyFileSync(source,target);
}
