import {readdirSync,rmSync} from 'node:fs';
const publicDir=new URL('../public/',import.meta.url);
const allowed=new Set(['index.html','walker.bundle.js','walker.bundle.css','walker.css','licenses','honor-corridor','insta360','terrace','cafeteria','alpine-lake','hackathon']);
for(const name of readdirSync(publicDir))if(!allowed.has(name))rmSync(new URL(name,publicDir),{recursive:true,force:true});
